package com.inventory.management.dao;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.inventory.management.entity.Product;

@Repository
@Transactional
public interface InventoryRepo extends JpaRepository<Product,Integer > {
	
    int deleteByExpiryDateLessThan(LocalDate date);
    
    Optional<Product> findByDescriptionLike(String desc);

}
