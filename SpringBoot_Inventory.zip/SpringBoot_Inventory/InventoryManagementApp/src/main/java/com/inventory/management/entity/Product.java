package com.inventory.management.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Column
	private String description;
	@Column
	private double weight;
	@Column
	private double price;
	@Column
	private LocalDate manufacturingDate;
	@Column
	private int useBeforeInMonths;
	@Column
	private LocalDate expiryDate;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int id, String description, double weight, double price, LocalDate manufacturingDate,
			int useBeforeInMonths, LocalDate expiryDate) {
		super();
		this.id = id;
		this.description = description;
		this.weight = weight;
		this.price = price;
		this.manufacturingDate = manufacturingDate;
		this.useBeforeInMonths = useBeforeInMonths;
		this.expiryDate = expiryDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public LocalDate getManufacturingDate() {
		return manufacturingDate;
	}

	public void setManufacturingDate(LocalDate manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}

	public int getUseBeforeInMonths() {
		return useBeforeInMonths;
	}

	public void setUseBeforeInMonths(int useBeforeInMonths) {
		this.useBeforeInMonths = useBeforeInMonths;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

}
