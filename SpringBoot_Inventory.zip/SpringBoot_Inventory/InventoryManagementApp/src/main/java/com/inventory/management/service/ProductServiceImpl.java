package com.inventory.management.service;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.inventory.management.dao.InventoryRepo;
import com.inventory.management.dto.ProductDTO;
import com.inventory.management.entity.Product;
import com.inventory.management.exception.ItemNotFoundException;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	InventoryRepo repo;
	
	@Override
	public void addProduct(ProductDTO productDTO) {
		Product product = new Product(productDTO.getId(), productDTO.getDescription(),productDTO.getWeight(), productDTO.getPrice(),
				 productDTO.getManufacturingDate(), productDTO.getUseBeforeInMonths(), productDTO.getExpiryDate());
		repo.save(product);
	}

	@Override
	public ProductDTO calculateExpiry(int id) {
		Product product = repo.getById(id);
		
		LocalDate manuDate= product.getManufacturingDate();
		
		int month = product.getUseBeforeInMonths();
		
		LocalDate expDate = manuDate.plusMonths(month);
		
		product.setExpiryDate(expDate);
		
		repo.save(product);
		
		return new ProductDTO(product.getId(), product.getDescription(),product.getWeight(), product.getPrice(),
				product.getManufacturingDate(), product.getUseBeforeInMonths(), product.getExpiryDate());
	}

	@Override
	public void removeExpiredProducts() {  
		repo.deleteByExpiryDateLessThan(LocalDate.now());
	}

	@Override
	public List<ProductDTO> getSortedProductsByExpiryDate() {
		
		List<Product> products = repo.findAll(Sort.by(Sort.Direction.DESC,"expiryDate"));
		List<ProductDTO> productDtoList = new ArrayList<>();
		for(Product product : products)
		{
			productDtoList.add(new ProductDTO(product.getId(), product.getDescription(),product.getWeight(), product.getPrice(),
				 product.getManufacturingDate(), product.getUseBeforeInMonths(), product.getExpiryDate()));
		}
		return productDtoList;
	}

	@Override
	public ProductDTO searchProductByDesc(String desc) throws ItemNotFoundException {
		Optional<Product> productOp = repo.findByDescriptionLike(desc);
		
		if(productOp.isPresent())
		{
			Product product=productOp.get();
			return new ProductDTO(product.getId(), product.getDescription(),product.getWeight(), product.getPrice(),
				 product.getManufacturingDate(), product.getUseBeforeInMonths(), product.getExpiryDate());
		}
		else {
			throw new ItemNotFoundException("No Item found with description "+desc);
		}
		
	}

	@Override
	public void applyDiscount() {
		List<Product> products = repo.findAll();
		
		for(Product product: products)
		{
			LocalDate from;
			LocalDate to;
			if(LocalDate.now().compareTo(product.getExpiryDate()) > 0)
			{
				from=product.getExpiryDate();
				to=LocalDate.now();
			}
			else {
				to=product.getExpiryDate();
				from=LocalDate.now();
			}
			long months = ChronoUnit.MONTHS.between(from, to);
			System.out.println(product.getDescription()+" expires in "+months);
			if(months<=6)
			{
				product.setPrice(product.getPrice()-(product.getPrice()*0.2));
				repo.save(product);
			}
		}

	}

}
