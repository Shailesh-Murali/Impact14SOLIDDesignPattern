package com.inventory.management.exception;

public class ItemNotFoundException extends Exception {
	
	private static final long serialVersionUID = -151858996416080055L;

	public ItemNotFoundException(String msg) {
		super(msg);
	}

}
