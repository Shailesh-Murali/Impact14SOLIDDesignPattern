package com.inventory.management.service;

import java.util.List;

import com.inventory.management.dto.ProductDTO;
import com.inventory.management.exception.ItemNotFoundException;

public interface ProductService {
	
	public void addProduct(ProductDTO product);

	public ProductDTO calculateExpiry(int id);

	public void removeExpiredProducts();

	public List<ProductDTO> getSortedProductsByExpiryDate();

	public ProductDTO searchProductByDesc(String id) throws ItemNotFoundException;

	public void applyDiscount();

}
