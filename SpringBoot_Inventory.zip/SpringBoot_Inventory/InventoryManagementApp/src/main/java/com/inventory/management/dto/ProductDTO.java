package com.inventory.management.dto;

import java.time.LocalDate;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Positive;

public class ProductDTO {
	
	
	private int id;
	@NotNull(message="Description is mandatory")
	private String description;
	@Positive(message="Weight cannot be 0 or negative")
	private double weight;
	@Positive(message="Price cannot be 0 or negative")
	private double price;	
	@PastOrPresent(message = "ManufacturingDate cannot be in future")
	private LocalDate manufacturingDate;
	@Positive(message="Use Before Months cannot be 0 or negative")
	private int useBeforeInMonths;
	private LocalDate expiryDate;
	
	
	public ProductDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public ProductDTO(int id, String description, double weight, double price, LocalDate manufacturingDate,
			int useBeforeInMonths, LocalDate expiryDate) {
		super();
		this.id = id;
		this.description = description;
		this.weight = weight;
		this.price = price;
		this.manufacturingDate = manufacturingDate;
		this.useBeforeInMonths = useBeforeInMonths;
		this.expiryDate = expiryDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public LocalDate getManufacturingDate() {
		return manufacturingDate;
	}
	public void setManufacturingDate(LocalDate manufacturingDate) {
		this.manufacturingDate = manufacturingDate;
	}
	public int getUseBeforeInMonths() {
		return useBeforeInMonths;
	}
	public void setUseBeforeInMonths(int useBeforeInMonths) {
		this.useBeforeInMonths = useBeforeInMonths;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "ProductDTO [id=" + id + ", description=" + description + ", weight=" + weight + ", price=" + price
				+ ", manufacturingDate=" + manufacturingDate + ", useBeforeInMonths=" + useBeforeInMonths
				+ ", expiryDate=" + expiryDate + "]";
	}
	
	

}
