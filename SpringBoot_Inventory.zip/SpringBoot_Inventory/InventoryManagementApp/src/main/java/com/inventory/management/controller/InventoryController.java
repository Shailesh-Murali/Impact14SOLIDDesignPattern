package com.inventory.management.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.inventory.management.dto.ProductDTO;
import com.inventory.management.exception.ItemNotFoundException;
import com.inventory.management.service.ProductService;

@Validated
@RestController
public class InventoryController {

	@Autowired
	ProductService productService;

	@PostMapping("/products")
	public ResponseEntity<String> addProduct(
			@RequestBody @NotEmpty(message = "Input movie list cannot be empty.") ArrayList<@Valid ProductDTO> products) {
		for (ProductDTO product : products) {
			productService.addProduct(product);
		}
		return new ResponseEntity<String>("Products Addded Successfully", HttpStatus.CREATED);
	}

	@PutMapping("/expiry/{id}")
	public ResponseEntity<ProductDTO> calculateExpiry(@PathVariable int id) {
		ProductDTO product = productService.calculateExpiry((int) id);
		return new ResponseEntity<ProductDTO>(product, HttpStatus.OK);
	}

	@DeleteMapping("/product")
	public ResponseEntity<String> removeExpiredProducts() {
		productService.removeExpiredProducts();
		return new ResponseEntity<String>("Expired Products Removed Successfully", HttpStatus.OK);

	}

	@GetMapping("/products")
	public ResponseEntity<List<ProductDTO>> getSortedProductsByExpiryDate() {
		List<ProductDTO> products = productService.getSortedProductsByExpiryDate();
		return new ResponseEntity<List<ProductDTO>>(products, HttpStatus.OK);
	}

	@PutMapping("/discount")
	public ResponseEntity<String> applyDiscount() {
		productService.applyDiscount();
		return new ResponseEntity<String>("Discount Applied Successfully", HttpStatus.OK);
	}

	@GetMapping("/product/{desc}")
	public ResponseEntity<ProductDTO> getProduct(@PathVariable String desc) throws ItemNotFoundException {
		ProductDTO product = null;

		product = productService.searchProductByDesc(desc);

		return new ResponseEntity<ProductDTO>(product, HttpStatus.OK);
	}

}
