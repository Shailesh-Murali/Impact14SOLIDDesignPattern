package com.infy.exception;

public class InfyAcademyException extends Exception {

	private static final long serialVersionUID = 1L;

	public InfyAcademyException(String message) {
		super(message);
	}

}
